
import pyautogui as spam
import time
print("   COPYRIGHT 2022-2023")
time.sleep(0.4)
print("   CREATED BY : THE GUY ")
time.sleep(0.4)
print("    ")
print("                                         ░██████╗██╗░██████╗░███╗░░░███╗░█████╗░")
print("                                         ██╔════╝██║██╔════╝░████╗░████║██╔══██╗")
print("                                         ╚█████╗░██║██║░░██╗░██╔████╔██║███████║")
print("                                         ░╚═══██╗██║██║░░╚██╗██║╚██╔╝██║██╔══██║")
print("                                         ██████╔╝██║╚██████╔╝██║░╚═╝░██║██║░░██║")
print("                                         ╚═════╝░╚═╝░╚═════╝░╚═╝░░░░░╚═╝╚═╝░░╚═╝")

print("\r   LOADING",end="")
time.sleep(1)
print("\r   PLEASE WAIT     ",end="")

time.sleep(1)
print("\r                                        ")

time.sleep(1)

print("")

count=int(input("   SPAM NUMBER : "))

msg=input("   PRINT YOUR MSG  :  ")

print("   OPEN A PLACE TO SPAM IN ")
time.sleep(2)
print("\r    5",end="")
time.sleep(1)
print("\r    4 ",end="")
time.sleep(1)
print("\r    3  ",end="")
time.sleep(1)
print("\r    2    ",end="")
time.sleep(1)
print("\r    1     ",end="")
time.sleep(1)
i=0
while i< (count):
    
    spam.typewrite(str(msg))
    spam.press("enter")
    i+=1
